# Enterprise Student Academic Management Platform

This repository contains the Unit-1 planning work for a proposed academic information system. The documentation covers the problem context, users, requirements, design-thinking activities, MVP boundaries, architecture, roadmap, and repository setup.

## Documentation Index

1. [Project Overview](01_Project_Overview.md)
2. [Business Requirements](02_Business_Requirements_Document_BRD.md)
3. [Product Vision](03_Product_Vision_Document.md)
4. [Stakeholder Analysis](04_Stakeholder_Analysis_Report.md)
5. [User Personas](05_User_Persona_Report.md)
6. [Functional Requirements](06_Functional_Requirements_Specification_FRS.md)
7. [Non-Functional Requirements](07_Non_Functional_Requirements_Specification_NFRS.md)
8. [Design Thinking](08_Design_Thinking_Report.md)
9. [IBM Design Thinking](09_IBM_Design_Thinking_Report.md)
10. [IBM Loop](10_IBM_Loop_Documentation.md)
11. [MVP Definition](11_Minimum_Viable_Product_MVP.md)
12. [Product Roadmap](12_Product_Roadmap.md)
13. [System Architecture](13_Initial_System_Architecture_Diagram.md)
14. [Project Charter](14_Project_Charter.md)
15. [Repository Initialization](15_Project_Repository_Initialization.md)
16. [Folder Structure](16_Project_Folder_Structure.md)
17. [Product Discovery](17_Product_Discovery_Documentation.md)
18. [Conclusion](18_Conclusion.md)
19. [Reference Basis](19_References_Source_Basis.md)

## Project Intent

The proposed system brings commonly used student and academic processes into one controlled environment. The initial release concentrates on student records, attendance, examination information, and academic reporting.

The documentation is deliberately separated from implementation code so that requirements and user needs can be reviewed before development begins.
